A = [17 8
    8 17]
[U,S,V] = svd(A)

U*sqrt(S)*sqrt(S)*V'
U*sqrt(S)*sqrt(S)*U'