clear all;
%% (1) 
% load data and generate test points
load("streambed_data.mat")
x_sharp = x;
N = length(x_sharp);
y_sharp = y;

x_star = -100:0.1:100;
M = length(x_star);

lambda = 2;
l = 5;
C_kernel = @(x) lambda^2 * exp(-(x).^2 / (2*l^2));
C_prior = C_kernel(x_star-x_star');
[U,S,V] = svd(C_prior);
L = U*sqrt(S);

h_prior_fun = @(x) -10 + 0*x;
h_prior = h_prior_fun(x_star');

f_star = repmat(h_prior,[1,10]) + L*randn([M,10]);

%%
figure('Name','Prior')
plot(x_star,f_star);
title('Plotmatrix of Generated 3D Data')